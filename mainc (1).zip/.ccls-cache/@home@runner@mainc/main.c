/*
Calcular e exibir a área e o comprimento de um círculo de Raio (R), sabendo que, Area = π * R2
e
Comprimento = 2 * π * R. Declarar o valor de π (PI = 3.14) como constante com comando: #define.
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14

int main(void) {
float area, comprimento, raio;
  printf("Digite o valor do raio: ");
  scanf("%f", &raio);
  //calculos
  area = PI * pow(raio, 2);
  comprimento = 2 * PI * raio;
  //exibir resultados
  printf("Area do círculo: %.2f\n", area);
  printf("Comprimento do círculo: %.2f\n", comprimento);
  
return 0;
}
