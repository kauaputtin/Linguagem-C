/*
Escrever um algoritmo que leia a nota [0.0 - 10.0] do 1º e 2º Bimetre de um (1) aluno

e exibir a sua média semestral final com sua classificação (Status), a saber:

-> Nota Semestral: [0, 3[ => Aluno Status: Reprovação.

-> Nota Semestral: [3, 10] => Aluno Status: Aprovação.
  */

#include <stdio.h>
#include <stdlib.h>


int main(void) {
float notab1, notab2, media;
printf("Digite a nota do primeiro bimestre: "); scanf("%f", &notab1);
printf("Digite a nota do segundo bimestre: "); scanf("%f", &notab2);

//calculo da media
media = (notab1 + notab2) / 2;
//verificação da situação do aluno
if(media >= 7)
  printf("Aluno Status: Aprovado com média %.2f" , media);
else (media <= 3);
  printf("Aluno Status: Reprovado com média %.2f" , media);
  


return 0;
}
