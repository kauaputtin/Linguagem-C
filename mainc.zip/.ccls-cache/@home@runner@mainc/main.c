/*EXEMPLO 5:
Enumerar e exibir na tela todas as sugestões de senhas numéricas
de 4 digitos (DISTINTOS ENTRE SI: NÃO REPETIDOS) com a seguinte "criptografia fraca":

-> PARES e NÃO MÚLTIPLAS DE 39.

VALOR INICIAL.           : 1000
VALOR FINAL (não incluso): 9999 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
 int contador, d1, d2, d3, d4;
  printf("Sugestões de senhas:\n");
  for (contador = 1000; contador <= 9999; contador ++) {
  
    d1 = contador / 1000;
    d2 = (contador % 1000) / 100;
    d3 = (contador % 100) / 10;
    d4 = contador % 10;
  
    if (d1 != d2 && d1 != d3 && d1 != d4 && d2 != d3 && d2 != d4 &&
        d3 != d4 &&
      contador % 2 != 0 && contador % 39 != 0) {
    printf("%i\n", contador);
    }
  }
  return 0;
}

