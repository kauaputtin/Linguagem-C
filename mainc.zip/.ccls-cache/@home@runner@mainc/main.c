/*
   ALGORITMO - SELEÇAO COMPOSTA: IF - ELSE
   Escrever um algoritmo que teste uma(1) senha numerica de exatamente 4 digitos.

  */


#include <stdio.h>
#include <stdlib.h>

int main(void){
  int senha; 
  printf("Digite uma senha númerica de 4 digitos(xxxx): ");
  scanf("%i", &senha);
  //TRATAMENTO DE ERRO
  if(senha < 1000 || senha > 9999)
    printf("ERRO: Senha deve conter exatamente 4 digitos.\n");
  
  else {
    //cripografia: impar e nao multipla de 17
    if(senha % 2 != 0 && senha % 17 != 0)
      printf("senha forte\n");
    else
      printf("senha fraca");
  }
   return 0;
}
