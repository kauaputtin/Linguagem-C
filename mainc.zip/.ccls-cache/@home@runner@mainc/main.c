/*
Calcular e exibir o tempo (em horas) de autonomia de uma caixa d’água de um restaurante que consome 1350 litros por hora em média. 
O tanque do restaurante é cilíndrico de base circular de Raio
(R) e de altura (H) em metros. Sabendo que 1 m3 = 1000 Litros.
*/

//1h  consome 1350L

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14

int main(void) {
float r, h, volume3, volumeL, autonomiaH;
  printf("Digite o raio do tanque(M): ");
  scanf("%f", &r);
  printf("Digite a altura do tanque(M): ");
  scanf("%f", &h);
  //calculo do volume
  volume3 = PI * pow(r,3) * h;
    printf("O volume do tanque é: %.2f\n", volume3);
  volumeL = volume3 * 1000;
  autonomiaH = volumeL / 1350;
  printf("A autonomia do tanque é: %.2f", autonomiaH);
return 0;
}
