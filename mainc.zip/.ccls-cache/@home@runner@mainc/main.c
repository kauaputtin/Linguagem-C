/*
Calcular e exibir a área de um quadrado de lado (L). Área = L2
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void) {

  float lado, area;
  printf("Digite o lado do quadrado(cm): ");
  scanf("%f", &lado);
  //calculo da area
  area = lado * lado;
  //exibir resultado
  printf("A área do quadrado é: %.2f", area);
return 0;
}
